//import UIKit

//Stored properties
//struct RangeLength{
//    var fnum = 0
//    let range = 3
//}
//
//class RangeLength2{
//    var fnum = 0
//    let range = 3
//}
//
//let a = RangeLength(fnum: 6)
//a = RangeLength()
//let b  = RangeLength2()
//b.fnum = 6
//    b.fnum = 7
//
//
//print(a)
//print(b.fnum)
//
//

//Computed properties

//struct Point {
//    var x = 0.0, y = 0.0
//}
//struct Size{
//    var width = 0.0, height = 0.0
//}
//struct Rect {
//    var origin = Point()
//    var size = Size()
//    var center: Point {
//        get {
//            let centerX = origin.x + (size.width / 2)
//            let centerY = origin.y + (size.height / 2)
//            return Point(x: centerX, y: centerY)
//        }
//        set(newCenter) {
//            origin.x = newCenter.x - (size.width / 2)
//            origin.y = newCenter.y - (size.height / 2)
//        }
//    }
//}
//var square = Rect(origin: Point(x: 0.0, y: 0.0),
//    size: Size(width: 10.0, height: 10.0))
//let initialSquareCenter = square.center
//// initialSquareCenter is at (5.0, 5.0)
//square.center = Point(x: 15.0, y: 15.0)
//print("square.origin is now at (\(square.origin.x), \(square.origin.y))")
//// Prints "square.origin is now at (10.0, 10.0)"


//Property Observers

//class Counter{
//    var count : Int = 0{
//        willSet{
//            print("about to set count to \(newValue)")
//        }
//        didSet{
//            if(count>oldValue){
//                print("Count is increased by \(count-oldValue)")
//            }
//        }
//    }
//}
//
//var a = Counter()
//a.count
//a.count = 5
//a.count
//a.count = 15


//Type properties (static and class)
struct SomeStructure {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }
    
    class var overrideableComputedTypeProperty: String {
        return "this is overrideableComputedTypeProperty"
    }
}

class Class1: SomeClass {
     override class var overrideableComputedTypeProperty: String{
        return "105 is override string"
    }
}

print(Class1.overrideableComputedTypeProperty)



