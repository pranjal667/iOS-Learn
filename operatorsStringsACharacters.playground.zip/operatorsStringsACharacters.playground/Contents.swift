import Foundation
import UIKit

//ternary operator in use

//let height = 20
//let width = 30
//let isThick = true
//let add =  height + (isThick ? 20 : 30)
//print(add)

// multiline comments

//var text = """
//            Hello there,
//
//                This is just a try.
//
//                    To see how multiline comments works.
//
//"""
//print(text)

// escaping characters

//var text = " Hello there,\n u{1F496} This is just a try. To see how the comments works."
//print(text )

//characters

//let catCharacters : [Character] = ["C", "a", "t", "!", "🐱"]
//let catString = String(catCharacters)
//print(catString)

// INDEX

//let word = "Pneumonoultramicroscopicsilicovolcanoconiosis is the longest word."
//word[word.startIndex]
//word[word.index(after: word.startIndex)]
//word[word.index(before: word.endIndex)]
//word[word.index(word.startIndex, offsetBy: 5)]



let greeting = "Hello, world!"
let index = greeting.firstIndex(of: ",")
