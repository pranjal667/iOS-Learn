import UIKit

//for loop

//using _ for unused var

//let base = 3
//let power = 10
//var answer = 1
//for _ in 1...power {
//    answer *= base
//}
//print("\(base) to the power of \(power) is \(answer)")

//using ranges

//var interval = 5
//let minutes = 60
//for tickMark in 0..<minutes {
//    print(tickMark)
//}
//for tickMark in stride(from: 0, through: minutes, by: interval){
//    print(tickMark)
//}


//While loop

//let finalSquare = 25
//var board = [Int](repeating: 0, count: finalSquare + 1)
//
//var square = 5
//var diceRoll = 2
//while square < finalSquare {
//    // roll the dice
//    diceRoll += 1
//    if diceRoll == 7 { diceRoll = 1 }
//    // move by the rolled amount
//    square += diceRoll
//    if square < board.count {
//        // if we're still on the board, move up or down for a snake or a ladder
//        square += board[square]
//    }
//}
//print("Game over!")
//
//repeat While (doWhile)
//repeat {
//    // move up or down for a snake or ladder
//    square += board[square]
//    // roll the dice
//    diceRoll += 1
//    if diceRoll == 7 { diceRoll = 1 }
//    // move by the rolled amount
//    square += diceRoll
//} while square < finalSquare
//print("Game over!")
//


//If Else
//temperatureInFahrenheit = 90
//if temperatureInFahrenheit <= 32 {
//    print("It's very cold. Consider wearing a scarf.")
//} else if temperatureInFahrenheit >= 86 {
//    print("It's really warm. Don't forget to wear sunscreen.")
//} else {
//    print("It's not that cold. Wear a t-shirt.")
//}


//SwitchCase

//let someCharacter: Character = "z"
//switch someCharacter {
//case "a":
//    print("The first letter of the alphabet")
//case "z":
//    print("The last letter of the alphabet")
//default:
//    print("Some other character")
//}

//tuples in SwitchCase

//let somePoint = (1, 1)
//switch somePoint {
//case (0, 0):
//    print("\(somePoint) is at the origin")
//case (_, 0):
//    print("\(somePoint) is on the x-axis")
//case (0, _):
//    print("\(somePoint) is on the y-axis")
//case (-2...2, -2...2):
//    print("\(somePoint) is inside the box")
//default:
//    print("\(somePoint) is outside of the box")
//}


//control transfer statements

//Continue
//let actualSentence = "Hello welcome to the game"
//var puzzleSentence = ""
//var removeChar : [Character] =  ["a","e","i","o","u"," "]
//for char in actualSentence{
//    if removeChar.contains(char){
//        continue
//    }
//    else{
//        puzzleSentence.append(char)
//    }
//}
//print(puzzleSentence)

//Fallthrough
//let integerToDescribe = 2
//var description = "The number \(integerToDescribe) is"
//switch integerToDescribe {
//case 2, 3, 5, 7, 11, 13, 17, 19:
//    description += " a prime number, and also"
//    fallthrough
//default:
//    description += " an integer."
//}
//print(description)


//Guard
//func greet(person: [String: String]) {
//    guard let name = person["name"] else {
//        return
//    }
//
//    print("Hello \(name)!")
//
//    guard let location = person["location"] else {
//        print("I hope the weather is nice near you.")
//        return
//    }
//
//    print("I hope the weather is nice in \(location).")
//}
//
//greet(person : ["name" : "Pranjal", "location" : "Kathmandu"])


//Defer

//var score = 6
//if score < 10 {
//    defer {
//        print(score)
//    }
//    print("score")
//    score += 5
//}

