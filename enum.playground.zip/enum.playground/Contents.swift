import UIKit

//simple syntax

//enum Beverage: CaseIterable{
//    case Tea, Coffee, Juice
//}
//
//var a = Beverage.allCases.count
//print(a)
//
//for beverages in Beverage.allCases{
//    print(beverages, terminator: " ")
//}

//associative value
//enum Barcode: CaseIterable {
//    case sun, mon, tue, wed, thu, fri
//}
//
//for days in Barcode.allCases{
//    switch(days){
//    case .sun:
//        print("Today is Sunday")
//
//    default:
//        print("i dont care")
//    }
//}

//raw values enum

//enum Planet:Int{
//    case mercury = 1 , venus ,  earth , mars , jupiter, saturn , uranus , neptune
//}
//
//let positionToFind = 9
//
//if let somePlanet = Planet(rawValue: positionToFind){
//    switch somePlanet {
//    case .earth:
//        print("\(positionToFind) is habitable")
//    default:
//        print("\(positionToFind) is inhabitable")
//    }
//}
//else{
//    print("no planet on \(positionToFind)")
//}


//recursive enum

//indirect enum ArithmeticExpression {
//    case number(Int)
//    case addition(ArithmeticExpression, ArithmeticExpression)
//    case multiplication(ArithmeticExpression, ArithmeticExpression)
//}
//
//let five = ArithmeticExpression.number(5)
//let four = ArithmeticExpression.number(4)
//let sum = ArithmeticExpression.addition(five, four)
//let product = ArithmeticExpression.multiplication(sum, ArithmeticExpression.number(2))
//
//func evaluate(_ expression: ArithmeticExpression) -> Int {
//    switch expression {
//    case let .number(value):
//        return value
//    case let .addition(left, right):
//        return evaluate(left) + evaluate(right)
//    case let .multiplication(left, right):
//        return evaluate(left) * evaluate(right)
//    }
//}
//
//print(evaluate(product))


//practice
enum Calculate{
    case num(Int)
}

let a = Calculate.num(5)
let b = Calculate.num(5)

//let add = Calculate.addition(a, b)

if(a == b){
    print("equal")
}
else{
    print("no")
}




