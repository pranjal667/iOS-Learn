import UIKit

//Arrays

//1. Write a function that takes an array of integers as an argument and returns the sum of all the even numbers in the array.

//func arr(A:[Int]) -> Int {
//    var sum = 0
//    for item in A{
//        if item % 2 == 0 {
//            sum += item
//        }
//        else{
//            continue
//        }
//    }
//    return sum
//}
//
//print("The sum of even number in given array is \(arr(A: [1,3,2,4,6,8,7,5])) .")


//2. Write a function that takes an array of strings as an argument and returns a new array with all the strings capitalized.

//func arr(A:[String]) -> [String] {
//    var updatedArr : [String] = []
//    for item in A{
//        updatedArr += [item.uppercased()]
//    }
//    return updatedArr
//}

//print("The sum of even number in given array is \(arr(A: ["sudip", "parth" , "roshan"])) .")


//3. Write a function that takes two arrays of integers as arguments and returns a new array that contains the common elements of the two arrays.

//func compare(arr1: [Int], arr2: [Int]) -> [Int]{
//    var common : [Int] = []
//    for item1 in arr1{
//        for item2 in arr2{
//            if item1 == item2{
//                common  += [item1]
//                break
//            }
//            else{
//                continue
//            }
//        }
//    }
//    return common
//}
//
//print("Common elements in given arrays are : \(compare(arr1: [1,2,3,4,5,6,7,8,9,10], arr2: [2,4,2,6,8,10]))")


//class Person {
//    var age : Int?
//    var name : String?
//    init() {
//        age = Int(readLine())
//        name = readLine()
//    }
//
//}


//Dictionaries

//1. Write a function that takes a dictionary with string keys and integer values as an argument and returns the key with the maximum value.

//func dict(dict1 : [String : Int]) -> String {
//    var maxValue = 0
//    var keyWithMaxValue = ""
//    for (key , value) in dict1{
//        if value > maxValue{
//            maxValue  = value
//            keyWithMaxValue = key
//        }
//    }
//    return keyWithMaxValue
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : 2]))



//2. Write a function that takes two dictionaries with string keys and integer values as arguments and returns a new dictionary that contains the sum of the values for each key that exists in both dictionaries.

//func dict(dict1 : [String:Int], dict2: [String:Int]) -> [String: Int] {
//    var dictSum : [String:Int] = [:]
//    var sumOfKeys = 0
//    for (key1, value1) in dict1{
//        for (key2, value2) in dict2{
//            if key1 == key2{
//                dictSum[key1] = value1 + value2
//            }
//        }
//    }
//    return dictSum
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : 7], dict2: [ "A" : 1 , "B" : 2 , "C" : 3]))


//3. Write a function that takes a dictionary with string keys and optional integer values as an argument and returns a new dictionary that only contains keys with non-nil values.

//func dict(dict1 : [String : Int?]) -> [String : Int] {
//    var dictWithNonNilValues : [String : Int] = [:]
//    for (key , value) in dict1 {
//        if value != nil{
//            dictWithNonNilValues[key] = value
//        }
//    }
//    return dictWithNonNilValues
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : nil]))



//Optionals:

//1. Write a function that takes an optional integer as an argument and returns "Even" if the integer is even, "Odd" if the integer is odd, and "Unknown" if the integer is nil.

func evenOrOdd(number: Int?) -> String {
    return number?.isMultiple(of: 2) == true ? "Even" : (number != nil ? "Odd" : "Unknown")
}

print(evenOrOdd(number: nil))


