import UIKit

//Class example

//class Bicycle {
//var name = ""
//var gears = 0
//}
//
//var bike1 = Bicycle()
//bike1.gears = 11
//bike1.name = "Mountain Bike"
//
//print("Name: \(bike1.name), Gears: \( bike1.gears) ")

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Multiple objects

//class Employee {
//
//var employeeID = 0
//}
//
//var employee1 = Employee()
//var employee2 = Employee()
//
//employee1.employeeID = 1001
//print("Employee ID: \(employee1.employeeID)")
//
//employee2.employeeID = 1002
//print("Employee ID: \(employee2.employeeID)")

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//Initializer

//class Bike {
//
//  var name: String
//  var gear: Int
//
//  init(name: String, gear: Int){
//    self.name = name
//    self.gear = gear
//  }
//}
//
//var bike1 = Bike(name: "BMX Bike", gear: 2)
//
//print("Name: \(bike1.name) and Gear: \(bike1.gear)")

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//CLASS VS STRUCTURE

//CLASS:REFERENCE TYPE
//class Bike {
//  var color: String
//
//  init(color:String) {
//    self.color = color
//  }
//}

//var bike1 = Bike(color: "Blue")
//
//var bike2 = bike1
//
//bike1.color = "Red"
//print(bike2.color)

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//STRUCT:VALUE TYPE
//
//struct Bike {
//  var color: String
//
//  init(color:String) {
//    self.color = color
//  }
//}
//
//var bike1 = Bike(color: "Blue")
//
//var bike2 = bike1
//
//bike1.color = "Red"
//print(bike2.color)

//
//class Person{
//    var name: String = "Ram"
//    var age : Int = 25
//
//    var displayInfo: (String, Int){
//        get{
//            var name1  =  name
//            var age1 = age
//            return(name1 ,  age)
//        }
//        set(age){
//            name  = "Pranjal"
//            var age = 24
//        }
//    }
//
//    func displayInfo( _ : String , _ : Int ) -> (String,Int){
//        return("Roshan" , 25)
//
//    }
//}
//
//var per1 = Person()
//
//
//// get value
//print("Get value:", per1.displayInfo)
//
//print("New num1 value:", per1.name)
//print("New num2 value:", per1.age)

//class Calculator {
//  var num1: Int = 0
//  var num2: Int = 0
//
//  // create computed property
//  var sum: Int {
//
//    // retrieve value
//    get {
//      num1 + num2
//    }
//
//    // set new value to num1 and num2
//    set(modify) {
//      num1 = (modify + 10)
//      num2 = (modify + 20)
//    }
//  }
//}
//
//var obj = Calculator()
//obj.num1 = 20
//obj.num2 = 50
//
//// get value
//print("Get value:", obj.sum)
//
//// provide value to modify
//obj.sum = 5
//
//print("New num1 value:", obj.num1)
//print("New num2 value:", obj.num2)
//
//
//
