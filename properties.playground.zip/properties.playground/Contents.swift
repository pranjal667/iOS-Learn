import UIKit

//properties

//class Person {
//
// var name: String = ""
// var age: Int = 0
//}
//
//var person1 = Person()
//
//person1.name = "Kevin"
//person1.age = 42
//
//print("Name:", person1.name)
//print("Age:", person1.age)


//computed properties

//class Calculator {
//
//  var num1: Int = 0
//  var num2: Int = 0
//
//  var sum: Int {
//
//    num1 + num2
//  }
//}
//var obj = Calculator()
//obj.num1 = 11
//obj.num2 = 12
//
//print("Sum:", obj.sum)


//computed properties using getter and setter

//class Calculator {
//  var num1: Int = 0
//  var num2: Int = 0
//
//  var sum: Int {
//
//    get {
//      num1 + num2
//    }
//
//    set(modify) {
//      num1 = (modify + 10)
//      num2 = (modify + 20)
//    }
//  }
//}
//
//var obj = Calculator()
//obj.num1 = 20
//obj.num2 = 50
//
//print("Get value:", obj.sum)
//
//obj.sum = 5
//
//print("New num1 value:", obj.num1)
//print("New num2 value:", obj.num2)

 
