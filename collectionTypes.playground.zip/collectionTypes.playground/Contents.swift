import UIKit

//Array

//var someInts : [Int] = [5,4,3,2,1]
//someInts.append(6)
//someInts.insert(0, at: 0)
//someInts.sort()
//print(someInts)
//someInts = []
//print(someInts)


//adding two array

//var threeValue = Array(repeating: 1, count: 3)
//var anotherThreeValue = Array(repeating: 6, count: 3)
//var allValue = threeValue + anotherThreeValue
//print(allValue)

//loop in array
//for items in someInts{
//    print(items)
//}

//Sets

//var letters = Set<Character>()
//letters.insert("a")
//print(letters)
//
//var genre: Set<String> = ["Rock", "Pop"]
//for items in genre{
//    print(items)
//}
//
////sorting set
//var even: Set<Int> = [6,2,8,4,10]
//for items in even.sorted(){
//    print(items)
//}

//Set operations

//let oddDigits: Set = [1, 3, 5, 7, 9]
//let evenDigits: Set = [0, 2, 4, 6, 8]
//let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]
//
//oddDigits.union(evenDigits).sorted()
//oddDigits.intersection(evenDigits).sorted()
//oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
//oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()


//Dictionaries

var ints : [Int:String] = [:]
ints[16] = "HELLO"
print(ints)

var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
airports["LHR"] = "London Heathrow"
if let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB") {
    print("The old value for DUB was \(oldValue).")
}

