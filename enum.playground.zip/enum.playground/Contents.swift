import UIKit

//simple syntax

//enum Beverage: CaseIterable{
//    case Tea, Coffee, Juice
//}
//
//var a = Beverage.allCases.count
//
//print(a)
//for beverages in Beverage.allCases{
//    print(beverages, terminator: " ")
//}


//enum WeekDay: CaseIterable {
//    case sun, mon, tue, wed, thu, fri
//}
//
//for days in WeekDay.allCases{
//    switch(days){
//    case .sun:
//        print("Today is Sunday")
//
//    default:
//        print("i dont care")
//    }
//}


// Associated Values
//enum Student: CaseIterable{
//    case name(String)
//    case age(Int)
//}

//enum Card {
//    case number(Int)
//    case face(String)
//
//    init(_ value: String) {
//        if let intValue = Int(value) {
//            self = .number(intValue)
//        } else {
//            self = .face(value)
//        }
//    }
//}


//raw values enum

//enum Planet:Int{
//    case mercury = 1 , venus ,  earth , mars , jupiter, saturn , uranus , neptune
//}
//
//let positionToFind = 9
//
//if let somePlanet = Planet(rawValue: positionToFind){
//    switch somePlanet {
//    case .earth:
//        print("\(positionToFind) is habitable")
//    default:
//        print("\(positionToFind) is inhabitable")
//    }
//}
//else{
//    print("no planet on \(positionToFind)")
//}


//recursive enum

//indirect enum ArithmeticExpression {
//    case number(Int)
//    case addition(ArithmeticExpression, ArithmeticExpression)
//    case multiplication(ArithmeticExpression, ArithmeticExpression)
//}
//
//let five = ArithmeticExpression.number(5)
//let four = ArithmeticExpression.number(4)
//let sum = ArithmeticExpression.addition(five, four)
//let product = ArithmeticExpression.multiplication(sum, ArithmeticExpression.number(2))
//
//func evaluate(_ expression: ArithmeticExpression) -> Int {
//    switch expression {
//    case let .number(value):
//        return value
//    case let .addition(left, right):
//        return evaluate(left) + evaluate(right)
//    case let .multiplication(left, right):
//        return evaluate(left) * evaluate(right)
//    }
//}
//
//print(evaluate(product))


// EQUATABLE PROTOCOL



//enum Weather: Equatable{
//    case sunny(Int)  , rainy, coudy
//}
//
//var checkWeather = Weather.sunny(1)
//var checkWeather2  = Weather.sunny(1)
//
//if checkWeather == checkWeather2 {
//    print("the weather will be sunny tomorrow aswell!!")
//}
//else{
//    print("damn the weather is unpredictable!!")
//}

//enum User {
//    case loggedIn(username: String)
//    case loggedOut
//}
//
//var user = User.loggedIn(username: "pranjal")
//var user2  = User.loggedIn(username: "pranjal")
//if user == user2 {
//    print("two same user inapplicable")
//}
//else{
//    print("applicable")
//}

//enum User: Equatable {
//    case loggedIn(username: String)
//    case loggedOut
//}
//
//var user1 = User.loggedIn(username: "john")
//var user2 = User.loggedIn(username: "john")
//
//if user1 == user2 {
//    print("two same user applicable")
//} else {
//    print("two different users")
//}



//
//switch user {
//case .loggedIn(let username):
//    print("User logged in as \(username)")
//case .loggedOut:
//    print("User logged out")
//}





enum DayOfWeek: Int {
    case Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
}

enum WeekendDay: DayOfWeek {
    case Saturday, Sunday
}

let today = DayOfWeek.Tuesday
print(today.rawValue) // 2

let weekend = WeekendDay.Saturday
print(weekend.rawValue) // 6
