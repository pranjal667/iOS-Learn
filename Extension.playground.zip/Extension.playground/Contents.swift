import UIKit

//Initalizer example of Extension

//struct Point{
//    var x = 0.0, y = 0.0
//}
//
//struct Size{
//    var width = 0.0 ,  height = 0.0
//}
//
//struct Rect{
//    var origin = Point()
//    var size  = Size()
//}
//
//extension Rect{
//    init(center: Point,  size: Size){
//        let originX = center.x - size.width/2
//        let originY = center.y - size.height/2
//        self.init(origin: Point(x: originX, y: originY), size: size)
//    }
//}
//
//let centerRect = Rect(center: Point(x:10, y:10), size: Size(width: 6, height: 8))

//class Wall {
//
//    var length : Double
//
//    func screen(){
//        print(length)
//    }
//}
//
//// create an object
//var wall1 = Wall()
//wall1.length = 5
//wall1.screen()


