import UIKit

//serial queue VS concurrent queue

//let queue = DispatchQueue(label: "LearningQueue", attributes: .concurrent)
//
//queue.async {
//    print("1 has started")
//    print("1 has ended")
//}
//
//queue.async {
//    print("2 has started")
//    print("2 has ended")
//}

//async VS sync

//queue.sync {
//    print("3 has started")
//    print("3 has ended")
//}
//
//queue.sync {
//    print("4 has started")
//    print("4 has ended")
//}


// Dispatch queue , Custom queue, GCD

var mainQueue = OperationQueue.main

var customQueue = OperationQueue()
customQueue.maxConcurrentOperationCount = 24

var fetchUserIdOperation = Operation()
fetchUserIdOperation.cancel()

var fetchUserPhotoWithIdOpertion =  Operation()
fetchUserPhotoWithIdOpertion.addDependency(fetchUserIdOperation)

customQueue.addOperation(fetchUserPhotoWithIdOpertion)


