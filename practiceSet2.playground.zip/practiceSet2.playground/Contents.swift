import UIKit

//Arrays:
//1. Write a function that takes an array of integers as an argument and returns the maximum sum that can be obtained by adding any consecutive elements of the array.
//2. Write a function that takes an array of tuples, where each tuple contains a string and an integer, and returns a dictionary where the keys are the strings and the values are the sum of the integers with that string.
//3. Write a function that takes an array of integers and returns a new array that contains the product of all the elements except the current element.

//###################################################################################################################################################################################//

//Dictionaries:
//1. Write a function that takes a dictionary with string keys and integer values as an argument and returns a new dictionary that contains the keys sorted in descending order by their values.
//2. Write a function that takes a dictionary with string keys and integer values and returns the key with the median value.
//3. Write a function that takes a dictionary with string keys and integer values and returns the key with the largest difference between its value and the average value of all the values.

//###################################################################################################################################################################################//

//Optionals:
//1. Write a function that takes an optional integer as an argument and returns the sum of all the digits of the integer.
//2. Write a function that takes an optional string as an argument and returns the number of unique characters in the string.
//3. Write a function that takes an optional array of integers as an argument and returns the maximum product that can be obtained by multiplying any three elements in the array.

//###################################################################################################################################################################################//

//Protocols:
//1. Define a protocol called `Serializable` that requires an implementation of a `serialize()` method that returns a string. Implement the protocol in a class called `Person` that has a name and an age, and write a function that takes an array of `Serializable` objects and returns a concatenated string of their serialized values.
//2. Define a protocol called `Comparable` that requires an implementation of a `compare()` method that takes another object of the same type and returns a Boolean value. Implement the protocol in a class called `Person` that has a name and an age, and write a function that takes an array of `Comparable` objects and returns the object with the smallest age.
//3. Define a protocol called `Parsable` that requires an implementation of a `parse()` method that takes a string and returns an object of the conforming type. Implement the protocol in a struct called `Rectangle` that has properties for width and height, and write a function that takes a string in the format "width,height" and returns a `Rectangle` object.

//###################################################################################################################################################################################//

//Generics:
//1. Write a function that takes an array of any type and a predicate function that takes an element of that type and returns a Boolean value. The function should return a new array that contains only the elements that satisfy the predicate.
//2. Write a function that takes a dictionary with any key and value types and returns a new dictionary that contains only the key-value pairs where the key is a string and the value is an integer.
//3. Write a function that takes an array of any type and returns a new array that contains only the elements that are instances of a specific class or subclass.

//###################################################################################################################################################################################//

//Extensions:
//1. Extend the `String` class with a method that returns a new string with all the vowels replaced by the next consonant in the alphabet.
//2. Extend the `Int` class with a method that returns a Boolean value indicating whether the integer is a prime number.
//3. Extend the `Double` class with a method that returns a string representation of the value in scientific notation with two decimal places.

//###################################################################################################################################################################################//

//Classes, structs, enums, and properties:
//1. Define a class called `Vehicle` with properties for speed, direction, and color. Define a subclass called `Car` that has a make and a model

//class Vehicle{
//    var speed: Int
//    var direction: String
//    var color: String
//    init(speed: Int, direction: String, color: String) {
//        self.speed = speed
//        self.direction = direction
//        self.color = color
//    }
//}
//
//class Car : Vehicle {
//    var make: String = "01/12/2022"
//    var model: String = "BMW"
//    override init(speed: Int, direction: String, color: String) {
//        self.speed = speed
//        self.direction = direction
//        self.color = color
//        
//    }
//    convenience init(make: String, model: String){
//        self.make = make
//        self.model = model
//    }
}
