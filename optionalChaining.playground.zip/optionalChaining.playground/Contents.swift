import UIKit


//class Person {
//    var residence: Residence?
//}
//
//class Residence {
//    var noOfRooms = 1
//}
//
//var roshan = Person()
//roshan.residence = Residence()
//if let roomCount = roshan.residence?.noOfRooms{
//    print(roomCount)
//}
//else{
//    print("i d c")
//}


//optional binding example in function

//func StudentInfo(id : Int) -> String? {
//    switch id {
//    case 1: return "You are 1"
//    case 2 : return "You are 2"
//    default:
//        return nil
//    }
//}
//
//let check = StudentInfo(id: 6) ?? "Hello"

