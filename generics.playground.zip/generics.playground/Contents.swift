import UIKit

//Normal generic example

//func addNum<T>(num : T){
//    print("Hello \(num)")
//}
//
//addNum(num: "beth")

//using protocol to generic type

 
