import UIKit

//Arrays

//1. Write a function that takes an array of integers as an argument and returns the sum of all the even numbers in the array.

//func arr(A:[Int]) -> Int {
//    var sum = 0
//    for item in A{
//        if item % 2 == 0 {
//            sum += item
//        }
//        else{
//            continue
//        }
//    }
//    return sum
//}
//
//print("The sum of even number in given array is \(arr(A: [1,3,2,4,6,8,7,5])) .")


//2. Write a function that takes an array of strings as an argument and returns a new array with all the strings capitalized.

//func arr(A:[String]) -> [String] {
//    var updatedArr : [String] = []
//    for item in A{
//        updatedArr += [item.uppercased()]
//    }
//    return updatedArr
//}

//print("The sum of even number in given array is \(arr(A: ["sudip", "parth" , "roshan"])) .")


//3. Write a function that takes two arrays of integers as arguments and returns a new array that contains the common elements of the two arrays.

//func compare(arr1: [Int], arr2: [Int]) -> [Int]{
//    var common : [Int] = []
//    for item1 in arr1{
//        for item2 in arr2{
//            if item1 == item2{
//                common  += [item1]
//                break
//            }
//            else{
//                continue
//            }
//        }
//    }
//    return common
//}
//
//print("Common elements in given arrays are : \(compare(arr1: [1,2,3,4,5,6,7,8,9,10], arr2: [2,4,2,6,8,10]))")


//class Person {
//    var age : Int?
//    var name : String?
//    init() {
//        age = Int(readLine())
//        name = readLine()
//    }
//
//}

//###################################################################################################################################################################################//


//Dictionaries

//1. Write a function that takes a dictionary with string keys and integer values as an argument and returns the key with the maximum value.

//func dict(dict1 : [String : Int]) -> String {
//    var maxValue = 0
//    var keyWithMaxValue = ""
//    for (key , value) in dict1{
//        if value > maxValue{
//            maxValue  = value
//            keyWithMaxValue = key
//        }
//    }
//    return keyWithMaxValue
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : 2]))



//2. Write a function that takes two dictionaries with string keys and integer values as arguments and returns a new dictionary that contains the sum of the values for each key that exists in both dictionaries.

//func dict(dict1 : [String:Int], dict2: [String:Int]) -> [String: Int] {
//    var dictSum : [String:Int] = [:]
//    var sumOfKeys = 0
//    for (key1, value1) in dict1{
//        for (key2, value2) in dict2{
//            if key1 == key2{
//                dictSum[key1] = value1 + value2
//            }
//        }
//    }
//    return dictSum
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : 7], dict2: [ "A" : 1 , "B" : 2 , "C" : 3]))


//3. Write a function that takes a dictionary with string keys and optional integer values as an argument and returns a new dictionary that only contains keys with non-nil values.

//func dict(dict1 : [String : Int?]) -> [String : Int] {
//    var dictWithNonNilValues : [String : Int] = [:]
//    for (key , value) in dict1 {
//        if value != nil{
//            dictWithNonNilValues[key] = value
//        }
//    }
//    return dictWithNonNilValues
//}
//
//print(dict(dict1: [ "A" : 5 , "B" : 6 , "C" : nil, "D" : 2]))

//###################################################################################################################################################################################//

//Optionals:

//1. Write a function that takes an optional integer as an argument and returns "Even" if the integer is even, "Odd" if the integer is odd, and "Unknown" if the integer is nil.

//Using if let

//func evenOrOdd(number: Int?) -> String{
//    return number?.isMultiple(of: 2) == true ? "Even" : (number != nil ? "Odd" : "Unknown")
//    if let val = number {
//        print("num is not nil")
//    }
//    else{
//        print("value is nil")
//    }
//}
//
//print(evenOrOdd(number: nil))

//Using guard let
//func evenOrOdd(number: Int?) -> String {
//    guard let val = number else {
//        return "Unknown"
//    }
//    return val.isMultiple(of: 2) ? "Even" : "Odd"
//}
//
//print(evenOrOdd(number: nil))

//Using optional chaining
//func evenOrOdd(number: Int?) -> String{
//    return number?.isMultiple(of: 2) == true ? "Even" : (number != nil ? "Odd" : "Unknown")
//}
//print(evenOrOdd(number: nil))


//2. Write a function that takes an optional string as an argument and returns the length of the string if it exists, and nil otherwise.

//func lengthOfString(giveString : String?) -> Int {
//    if let newString = giveString {
//        return newString.count
//    }else{
//        return 0
//    }
//}
//print("length of given string is \(lengthOfString(giveString: "hello"))")
//print("length of given string is \(lengthOfString(giveString: ""))")

//using optional Chaining

//func lengthOfString(giveString : String?) -> Int {
//    return giveString?.count ?? 0
//}
//print("length of given string is \(lengthOfString(giveString: "hello"))")
//print("length of given string is \(lengthOfString(giveString: ""))")


//3. Write a function that takes an optional array of integers as an argument and returns the sum of all the elements in the array if it exists, and nil otherwise.

//func sumOfElements(arr : [Int]?) -> Int? {
//    var sum = 0
//    if let newArr = arr{
//        for items in newArr{
//            sum += items
//        }
//        return sum
//    } else {
//            return nil
//        }
//    }
//
//print(sumOfElements(arr:[1,2,3,4,5])!)
//print(sumOfElements(arr: nil) as Any)


//###################################################################################################################################################################################//

//Protocols

//1. Define a protocol called `Drawable` that requires an implementation of a `draw()` method. Implement the protocol in a class called `Circle`.

//protocol Drawable{
//    func draw()
//}
//
//class Circle: Drawable{
//    func draw() {
//        let radius = 5
//        let area = 22 / 7 * radius * radius
//    }
//}


//2. Define a protocol called `Sortable` that requires an implementation of a `sort()` method. Implement the protocol in a class called `Person` that has a name and an age.

//protocol Sortable{
//    func sort()
//}
//
//class Person: Sortable{
//    var name : String
//    var age : Int
//    init(name: String, age: Int = 15){
//        self.name = name
//        self.age = age
//    }
//    func sort(){
//        print("The age of \(name) is \(age)")
//    }
//}


//3. Define a protocol called `Movable` that requires an implementation of a `move()` method. Implement the protocol in a class called `Car` that has a speed and a color.
 
//protocol Movable{
//    func move()
//}
//
//class Car: Movable{
//    var speed : Float
//    var color : String
//    init(speed : Float, color: String){
//        self.speed = speed
//        self.color = color
//    }
//    func move() {
//        print("The \(color) car is moving at \(speed) kmph.")
//    }
//}
//

//###################################################################################################################################################################################//

//Generics:

//1. Write a function that takes an array of any type and returns a new array with the elements in reverse order.
    
//func arrays<anyTypes>(arr : [anyTypes]) -> [anyTypes]{
//    return arr.reversed()
//}
//
//print("The reversed for the given array [1,2,3,4,5] is: \(arrays(arr: [1,2,3,4,5]))")
//print("The reversed for the given array [1.0,2.1,3.2,4.3,5.4] is: \(arrays(arr: [1.0,2.1,3.2,4.3,5.4]))")
//print("The reversed for the given array [Apple, Banana, Cat, Dog, Elephant] is: \(arrays(arr: ["Apple", "Banana", "Cat", "Dog", "Elephant"]))")

//2. Write a function that takes two arrays of the same type and returns a new array that contains the elements of both arrays in alternating order.

//func arrays<anyType>(arr1 : [anyType], arr2: [anyType]) -> [anyType]{
//    var arr3: [anyType] = []
//    var maxCount = max(arr1.count, arr2.count)
//    for elements in 0..<maxCount{
//        if elements < arr1.count{
//            arr3.append(arr1[elements])
//        }
//        if elements < arr2.count{
//            arr3.append(arr2[elements])
//        }
//    }
//    return arr3
//}
//print("The alternaing array is \(arrays(arr1: [1,2,3,4,5], arr2: [6,7,8,9,10,11]))")


//3. Write a function that takes an array of any type and returns a dictionary that contains the frequency of each element in the array.

//func array<anyType>(arr:[anyType]) -> [anyType:Int]{
//    var dict : [anyType : Int] = [:]
//    for i in 0..<arr.count{
//       var count = 0
//        for j  in 0..<arr.count{
//            if arr[i]==arr[j]{
//                count += 1
//            }
//            dict[arr[i]] = count
//        }
//    }
//    return dict
//}

//simpler version of above

//func array<T>(arr: [T]) -> [T: Int] {
//    var dict: [T: Int] = [:]
//    for items in arr {
//        dict[items, default: 0] += 1
//
//    }
//    return dict
//}
//
//
//print(array(arr: [1,2,1,4,2,3,2,1,1,3,1,5,4]))


//###################################################################################################################################################################################//

//Extensions:

//1. Extend the `String` class with a method that returns the length of the string without counting spaces.

//extension String{
//    func countWithoutSpace() -> Int {
//        var count = self.count
//        for items in self{
//            if items == " " {
//                count -= 1
//            }
//        }
//     return count
//    }
//}
//
//var a: String = "Hello World"
//print(a.countWithoutSpace())


//2. Extend the `Int` class with a method that returns the factorial of the integer.

//extension Int{
//    func factorial() -> Int{
//        var count = 1
//        for i in 1...self{
//            count *= i
//        }
//        return count
//    }
//}
//
//var a : Int = 3
//print("the factorial of \(a) is \(a.factorial())")



//3. Extend the `Double` class with a method that converts the value to a percentage string with two decimal places.

//extension Double {
//    func convertToPercent() -> String {
//        var percent = self * 100
//        var twoDecimalPlace = String(format: "%.2f", percent)
//        return twoDecimalPlace + "%"
//    }
//}
//
//var value: Double = 0.98765
//print("Converting \(value) to percentage string, we get : \(value.convertToPercent()) ")


//###################################################################################################################################################################################//

//Classes, structs, enums, and properties

//1. Define a class called `Person` with properties for name, age, and gender. Create an instance of the class and print out its properties.

//class Person{
//    var name: String
//    var age : Int
//    var gender : String
//    init(name: String, age : Int, gender: String){
//        self.name = name
//        self.age = age
//        self.gender = gender
//    }
//}
//
//var instanceOfPerson = Person(name: "Pranjal", age: 24, gender: "Male")
//print(instanceOfPerson.name, instanceOfPerson.age, instanceOfPerson.gender)


//2. Define a struct called `Rectangle` with properties for width and height. Create an instance of the struct and print out its area.

//struct Rectangle{
//    var width, height: Int
//    init(width: Int, height: Int) {
//        self.width = width
//        self.height = height
//    }
//}
//
//var rect1  =  Rectangle(width: 5, height: 6)
//print("area of given rectangle = \(rect1.width * rect1.height)")


//3. Define an enum called `Direction` with cases for north, south, east, and west. Create a variable of the enum type and print out its value.

enum Direction{
    case east, west, north, south
}

var checkDirection = Direction.east
print(checkDirection)
