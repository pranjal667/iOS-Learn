import UIKit

//Using functions with and without return type

//func printAndCount(string: String) -> Int {
//    print(string)
//    return string.count
//}
//func printWithoutCounting(string: String) {
//  let _ = printAndCount(string: string)
//}
//printAndCount(string: "hello, world")
//// prints "hello, world" and returns a value of 12
//printWithoutCounting(string: "hello, world")
//// prints "hello, world" but doesn't return a value


//to find minimum and maximum numbers in an array

//func minMax(array : [Int])-> (max : Int, min : Int){
//    var currentMin = array[0]
//    var currentMax = array[0]
//    for num in 1..<array.count{
//        if array[num] < currentMin{
//            currentMin = array[num]
//        }
//        else if array[num] > currentMax{
//        currentMax = array[num]
//        }
//    }
//    return (currentMax, currentMin)
//}
//
//let array2 = [32,12,99,56,7,2,34,65]
//print(minMax(array: array2))



// to omit Arguments
//func getName(for name: String) {
//    print(name)
//}
//
//func getNameNew(_ name: String, _ age: Int) {
//    print(name, age)
//}
//
//func getNameAgain(name: String, age: Int) {
//    print(name)
//}
//
//getName(for: "Pranjal")
//getNameNew("Pranjal", 22)
//getNameAgain(name: "Pranjal", age: 22)

//InOut
func swapTwoInts(_ a : inout Int, _ b : inout Int) {
    var temporaryA = a
    a = b
    b = temporaryA
}
var someInt = 3
var anotherInt = 107
swapTwoInts(&someInt, &anotherInt)
print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")




